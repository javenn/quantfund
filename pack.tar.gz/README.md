# quantfund
quant for funds

this is quant for funds;
