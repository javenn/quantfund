nohup jupyter notebook --port 9999 --no-browser --ip=0.0.0.0&
